XpX <- matrix(0,4,4)
XpX[1, ] <- c(20, 226.8, 54.1, 12.7)
XpX[2, ] <- c(226.8,  3135.8 , 757.06 , 133.98)
XpX[3, ] <- c(54.1, 757.06 ,190.97, 32.339)
XpX[4, ] <- c(12.7, 133.98, 32.339, 9.3258) 


XpY <- matrix(c(40.7378, 527.2645, 111.4137, 22.89),ncol = 1)

betahat <- solve(XpX) %*%X pY

n <- 100

Fmin <- function(u){
  R  <- matrix(1, n,4)
  R[,2] = u[1:n]
  R[,3] = u[(n+1):(2*n)]
  R[,4] = u[(2*n+1):(3*n)]
  RpR <- t(R) %*% R; 
  res <- sum((XpX - RpR)^2)
  return(res)
} 
u.init <- rep(XpX[1,2:4]/20,each=n) + rnorm(3*n,0,1)
sol <- optim( u.init,Fmin)
sol$value
Xsol <- matrix(1, n,4)
Xsol[,2] = sol$par[1:n]
Xsol[,3] = sol$par[(n+1):(2*n)]
Xsol[,4] = sol$par[(2*n+1):(3*n)]
Xsol


t(Xsol)%*%Xsol %*% matrix(betahat,ncol=1)
t(Xsol)%*%Xsol


Xdataframe <- as.data.frame(Xsol[,-1])
Xdataframe[,2] <- round(Xsol[,3]*1000)
names(Xdataframe) <- c('humidity_index','altitude_index','orientation_index')

Xmatrix = cbind(rep(1,n),Xdataframe)
betatrue <- betahat*c(10,1,1/1000,1)
betatrue[2] = 0
Y <- as.matrix(Xmatrix) %*% betatrue + rnorm(n,0,1)
data_butterflies = Xdataframe
data_butterflies$logabondance <- Y
data_butterflies$logabondance[3] <- data_butterflies$logabondance[3]*2


############## data aggregées


