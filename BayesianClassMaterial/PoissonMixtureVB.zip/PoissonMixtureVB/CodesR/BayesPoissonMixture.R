rm(list = ls())
######
library(gtools)
source('BayesPoissonMixture_functions.R')

############### paramètres de simulation
K <- 3;
pi_prop <- c(1/6,1/2,1/3)
sum(pi_prop)
mutrue <- c(10,20,30)

###############  Simulation
n <-  100
Ztrue  <- t(rmultinom(n, 1, prob= pi_prop))
Zsim <- Ztrue %*%(1:K)

Y <- rpois(n, Ztrue %*% mutrue)

hist(Y)


################## Prior  #######################
muprior <- 20
sprior <- 50
b = muprior/sprior^2
a = b*muprior;
e = rep(1,K)
par(mfrow=c(1,1))
curve(dgamma(x,a,b),0,100)
################# VBEM ############################
source('BayesPoissonMixture_functions.R')
res_VB <- VBEM_PoissonMixtures(Y,a,b,e)

res_VB$iter

Ntrue <- colSums(Ztrue)
Strue <- c(Y%*% Ztrue)
par(mfrow = c(2,K))
for (k in 1:K) {
  curve(dgamma(x,res_VB$aVB[k],res_VB$bVB[k]),min(Y),max(Y),ylab = 'dens',col = 'red',main=paste('mu',k,sep=''))
  curve(dgamma(x,a+Strue[k],b+Ntrue[k]),ylab = 'dens',col = 'orange',add=TRUE)
  curve(dgamma(x,a ,b ),add = TRUE,col = 'green')
  abline(v  = mutrue[k],col = 'purple')
}

for (k in 1:K) {
  curve(dbeta(x,res_VB$eVB[k],sum(res_VB$eVB) - res_VB$eVB[k]),0,1,ylab = 'dens',col = 'red')
  curve(dbeta(x,e[k] ,sum(e) - e[k] ),add = TRUE,col = 'green')
  curve(dbeta(x,e[k]+Ntrue[k],sum(e)+n-e[k]-Ntrue[k]),col='orange',add =TRUE)
  abline(v  = pi_prop[k],col = 'purple')
}

Zhat <- apply(res_VB$tau,1,which.max)
table(Zhat,Zsim)

# ###################################################""
# ######### GIBBS  POISSON mixtures##################
# ###################################################"""
# M = 5000
# res_Gibbs <- Gibbs_PoissonMixtures(Y,a,b,e,M)
#
#
# #-------------- BURN in
# ind <- seq(M/2,M,by = 5)
# mu_post <- res_Gibbs$mat_mu[ind,]
# pi_post <- res_Gibbs$mat_pi[ind,]
#
#
# # TRAJECTOIRES
# par(mfrow = c(2,K))
# for (k in 1:K){
#   plot(mu_post[,k],type='l')
#   abline(h  = mutrue[k],col='purple',lwd=2)
# }
# for (k in 1:K){
#   plot(pi_post[,k],type='l')
#   abline(h  = pi_prop[k],col='purple',lwd=2)
# }
#
# ############################# LOIS a posteriori
#
# par(mfrow = c(2,K))
# for (k in 1:K) {
#   xlim <- range(mu_post[,k])
#   curve(dgamma(x,res_VB$aVB[k],res_VB$bVB[k]),xlim[1],xlim[2],ylab = 'dens',col = 'red')
#   curve(dgamma(x,a ,b ),add = TRUE,col = 'green')
#   lines(density(mu_post[,k]),col='magenta')
#   abline(v  = mutrue[k],col = 'purple')
# }
# for (k in 1:K) {
#   curve(dbeta(x,res_VB$eVB[k],sum(res_VB$eVB) - res_VB$eVB[k]),0,1,ylab = 'dens',col = 'red')
#   curve(dbeta(x,e[k] ,sum(e) - e[k] ),add = TRUE,col = 'green')
#   abline(v  = pi_prop[k],col = 'purple')
#   lines(density(pi_post[,k]),col ='magenta')
# }
#
#
#
# ###################" Loi a posteriori sur les sommes
#
# sum_mu_GIBBS = rowSums(mu_post)
# MC <- sum_mu_GIBBS
# sum_mu_VB   = rowSums(sapply(1:K,function(k){rgamma(M,res_VB$aVB[k],res_VB$bVB[k])}))
# par(mfrow=c(1,1))
# plot(density(sum_mu_GIBBS),col='magenta',type='l')
# lines(density(sum_mu_VB),col='red')
