rm(list=ls())


###### 
library(mvtnorm)
 
############### paramètres de simulation
seed <- sample(1:100,1)
set.seed(seed)
pall <- 4
n <- 100 
X <- matrix(0,n,pall)
X[,1] <- 1
X[,2] <- seq(-1,1,len=n)
X[,3] <- seq(-1,1,len=n)^2
X[,4] <- cos(2*pi*seq(-1,1,len=n))
beta <- c(1,1.5,0.6,1)
 p  <-  length(beta)
# p  =1 
# X = matrix(X[,1:p],nrow=n,ncol=p)
# beta <- beta[1:p]
###############  Simulation 
Y <- rpois(n,exp(X %*% beta))
hist(Y)
##############" GLM frequentist
res_lm <- glm(Y ~ -1+X, family = poisson)
S <- summary(res_lm)$cov.scaled
res_lm$coefficients
############ prior
mu_beta <- rep(0,p)
Omega_beta <- 100 * diag(1,p)




###################################################""
######### MH  #####################################""
#####################################################"""



#------------ Algo 
MH_glmPois  = function(M,rho,Y,X,Omega_beta){ 
  
  p <- ncol(X)
  mat_beta <- matrix(0,M,p)
  S <- diag(1,p) 
  
  #---------- Initialisation
  
  beta <- c(rmvnorm(1,rep(0,p),Omega_beta)) # initiatlisation sous la loi a priori
  log_joint_prob <- sum(Y * X %*% beta) - sum(exp(X %*% beta)) + dmvnorm(beta,rep(0,p),Omega_beta,log = TRUE)
  accept <- 0
  for (m in 1:M) {
    
    if(m %% 1000 == 0) {print(m)}
    
    beta_c <- c(beta + rmvnorm(1,rep(0,p),rho*S))
    log_joint_prob_c <- sum(Y * X %*% beta_c) - sum(exp(X %*% beta_c)) + dmvnorm(beta_c,rep(0,p),Omega_beta,log=TRUE)
    alpha <- log_joint_prob_c - log_joint_prob
    
    if (log(runif(1)) < alpha){
      beta <-  beta_c
      log_joint_prob <- log_joint_prob_c
      accept <- accept + 1 
    }
    mat_beta[m,] = beta
  }
  return(list(sample = mat_beta,rate_accept = accept/M))
}

M  = 10000
res_MH_1 <- MH_glmPois(M,rho = 0.00001,Y,X,Omega_beta)
res_MH_2 <- MH_glmPois(M,rho = 0.004,Y,X,Omega_beta)
res_MH_3 <- MH_glmPois(M,rho = 0.05,Y,X,Omega_beta)


#------------ Algo 
MHGibbs_glmPois  = function(M,rho,Y,X,Omega_beta){ 
  
  p <- ncol(X)
  mat_beta <- matrix(0,M,p)
  S <- diag(1,p) 
  res_lm <- glm(Y ~ -1+X, family = poisson)
  S <- summary(res_lm)$cov.scaled
  
  #---------- Initialisation
  #beta <- c(rmvnorm(1,rep(0,p),Omega_beta)) # initiatlisation sous la loi a priori
  beta = res_lm$coefficients
  log_joint_prob <- sum(Y * X %*% beta) - sum(exp(X %*% beta)) + dmvnorm(beta,rep(0,p),Omega_beta,log = TRUE)
  accept <- 0
  for (m in 1:M) {
    
    if(m %% 1000 == 0) {print(m)}
    
    for (k in 1:p){
        beta_c <- c(beta)
        v <- sample(1:length(rho),1)
        beta_c[k] <- beta[k]+ rnorm(1,0,rho[v])
        log_joint_prob_c <- sum(Y * X %*% beta_c) - sum(exp(X %*% beta_c)) + dmvnorm(beta_c,rep(0,p),Omega_beta,log=TRUE)
        alpha <- log_joint_prob_c - log_joint_prob
    
        if (log(runif(1)) < alpha){
          beta <-  beta_c
          log_joint_prob <- log_joint_prob_c
          accept <- accept + 1 
        }
    }
    
    mat_beta[m,] = beta
  }
  return(list(sample = mat_beta,rate_accept = accept/M))
}
M  = 10000
res_MH_4 <- MHGibbs_glmPois(M,rho = c(0.01,0.04,0.1,0.5),Y,X,Omega_beta)


#################################################" 
#-------------------- SORTIES

burnin <- 9000; 

plot_MH <- function(burnin,res_MH){

  M <- nrow(res_MH$sample)
  ind <- seq(burnin,M,by = 1)
  mat_beta <- res_MH$sample
  p <- ncol(mat_beta)
  if (p >= 2){par(mfrow = c(p/2,2))} else{ par(mfrow = c(1,1))}
  for (j in 1:p) {
    plot(mat_beta[ind,j],type='l')
  }
  print(res_MH$rate_accept)
}

plot_MH(burnin,res_MH_1)
plot_MH(burni
        
        n,res_MH_2)
plot_MH(burnin,res_MH_3)
plot_MH(burnin,res_MH_4)

par(mfrow=c(2,2))
ind = seq(burnin,M)
acf(res_MH_1$sample[ind,1],main = "acf")
acf(res_MH_2$sample[ind,1],main = "")
acf(res_MH_3$sample[ind,1],main = "")

