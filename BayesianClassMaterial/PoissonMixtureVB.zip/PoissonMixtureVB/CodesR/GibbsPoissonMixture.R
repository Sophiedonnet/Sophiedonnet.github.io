


par(mfrow=c(1,1))
res_BM <- BM_poisson("SBM",Y)
res_BM$estimate()
res_BM$ICL
Zinit <- matrix(0,n,K)
tau_estim <- res_BM$memberships[[3]]$Z
for (i in 1:n){
   k  <- which.max(tau_estim[i,])
   Zinit[i,k] <- 1
}

############ prior
mean(Y)
alpha = 0.05
beta = 0.0025
curve(dgamma(x,alpha,beta),0,200)
nu <- rep(1,K)

######### GIBBS 
Zind <- Zinit
M = 10000; 
mu <- matrix(mean(Y),K,K)
pi <- rep(1,K)
O <- ######  




